# Business Claim Desk — Chrome new-tab extension

## Install on Chrome (Windows, Mac or Linux)
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. Click Load unpacked and select the business-claims-tab folder containing manifest.json.
5. Open a new tab. Accept Chrome's new-tab change prompt if shown.

## Use
Save your business profile. Open Class Action Payouts using the header link, or run a business settlement search. Add a listing URL, eligibility requirements, deadline, and evidence notes. Confirm terms against the official settlement administrator before filing. Update status manually as the claim progresses. Export a backup regularly; importing replaces all current data after confirmation.

This is an independent research tracker inspired by the requested source, not a copy or affiliated product. The source site could not be retrieved during development. No claims, payout amounts or eligibility determinations are preloaded. No live data feed, scraping, automatic matching, claim submission or background notifications. The deadline counter refreshes when the page opens or changes; reload a tab left open overnight.

Data is saved in chrome.storage.local in this Chrome profile, not synced or sent to a server by the extension. External links/searches contact their respective websites. Research search sends the entered industry and vendor text to Google. Do not enter tax IDs, banking data or confidential evidence. Removing the extension removes its local data; export first. Simultaneous edits across tabs can overwrite changes, so use one tab for editing.

Permissions: storage only. No access to your browsing history, page content or accounts. No remote scripts, dependencies, API keys or build tools required. Manifest V3, external JS and CSS.

To uninstall: chrome://extensions → Business Claim Desk → Remove.

Validation: JavaScript syntax, manifest paths and ZIP integrity checked. Automated browser checks could not run because a Chromium executable was unavailable. Chrome's Load unpacked workflow should still be checked on your own Chrome installation.
